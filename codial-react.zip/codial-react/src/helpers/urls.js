const API_ROOT = 'http://localhost:8000/api/v1';
const APIUrls = {
  login: () => 'http://localhost:8000/api/v1/users/create-session',
  signup: () => 'http://localhost:8000/api/v1/users/create-user',
  fetchPosts: () => `${API_ROOT}/posts`,
};

export default APIUrls;
