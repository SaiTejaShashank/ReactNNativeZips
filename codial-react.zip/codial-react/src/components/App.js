import React from 'react';
import { connect } from 'react-redux';
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Outlet,
  useLocation,
  //useNavigate,
  Navigate,
} from 'react-router-dom';
import PropTypes from 'prop-types';
import jwt_decode from 'jwt-decode';

import { fetchPosts } from '../actions/posts';
import Navbar from './Navbar';
import Page404 from './Page404';
import Home from './Home';
import Login from './Login';
import SignUp from './SignUp';
import Settings from './Settings';
import { authenticateUser } from '../actions/auth';

const PrivateRoute = (privateRouteProps) => {
  const currentPath = useLocation().pathname;

  //const navigate = useNavigate();

  const { isLoggedIn } = privateRouteProps;
  return isLoggedIn ? (
    <Outlet />
  ) : (
    <Navigate to="/login" state={{ from: currentPath }} />

    //navigate('/login', { state: { from: currentPath } })
  );
};

class App extends React.Component {
  componentDidMount() {
    this.props.dispatch(fetchPosts());

    const token = localStorage.getItem('token');
    if (token) {
      const user = jwt_decode(token);
      console.log('user token', user);
      this.props.dispatch(
        authenticateUser({
          email: user.email,
          _id: user._id,
          name: user.name,
        })
      );
    }
  }

  render() {
    const { posts, auth } = this.props;
    return (
      <Router>
        <div>
          <Navbar />
          <Routes>
            <Route exact path="/" element={<Home posts={posts} />} />
            <Route exact path="/login" element={<Login />} />
            <Route exact path="/signup" element={<SignUp />} />

            <Route
              exact
              path="/settings"
              element={<PrivateRoute isLoggedIn={auth.isLoggedIn} />}
            >
              <Route exact path="/settings" element={<Settings />} />
            </Route>

            <Route path="*" element={<Page404 />} />
          </Routes>
        </div>
      </Router>
    );
  }
}

function mapStateToProps(state) {
  return {
    posts: state.posts,
    auth: state.auth,
  };
}

App.protoTypes = {
  posts: PropTypes.array.isRequired,
  auth: PropTypes.object.isRequired,
};
export default connect(mapStateToProps)(App);
