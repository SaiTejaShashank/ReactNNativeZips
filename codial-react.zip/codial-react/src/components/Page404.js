import React from 'react';

export default function Page404() {
  return (
    <div>
      <h1>Page404</h1>
    </div>
  );
}
