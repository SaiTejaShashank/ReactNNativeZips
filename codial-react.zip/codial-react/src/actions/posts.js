import APIUrls from '../helpers/urls';
import { UPDATE_POSTS } from './actionTypes';

export function fetchPosts() {
  //let headers = new Headers();

  //headers.append('Content-Type', 'application/json');
  //headers.append('Accept', 'application/json');
  //headers.append('Origin', 'http://localhost:8000');

  return (dispatch) => {
    const url = APIUrls.fetchPosts();
    fetch(url, {
      mode: 'cors',
      //headers: headers,
    }).then((response) => {
      response.json().then((json) => {
        dispatch(updatePosts(json.posts));
      });
    });
  };
}

export function updatePosts(posts) {
  return {
    type: UPDATE_POSTS,
    posts,
  };
}
